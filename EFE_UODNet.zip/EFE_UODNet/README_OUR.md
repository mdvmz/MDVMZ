# <center>EFE_UODNet

### Installation

This project is based on [YOLOV8]([Pertical/YOLOv8: YOLOv8 🚀 in PyTorch > ONNX > CoreML > TFLite](https://github.com/Pertical/YOLOv8/tree/main)).

- Python 3.9
- Pytorch 2.1.2+cu118

**Step 1.** Create a conda virtual environment and activate it.

```bash
conda create -n name python=3.9
conda activate name
```

**Step 2.** Install PyTorch following [official instructions]([Previous PyTorch Versions](https://pytorch.org/get-started/previous-versions/)/).

Linux

```bash
# Pytorch 2.1.2+cu118
pip install torch==2.1.2 torchvision==0.16.2 torchaudio==2.1.2 --index-url https://download.pytorch.org/whl/cu118
```

**Step 3.** Install EFE_UODNet and dependent packages.

```bash
pip uninstall ultralytics
pip install -e .
pip install -U openmim -i https://pypi.tuna.tsinghua.edu.cn/simple
mim install mmengine -i https://pypi.tuna.tsinghua.edu.cn/simple
mim install "mmcv>=2.0.0" -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install -r requirements.txt
```

### Dataset

The data structure DUO looks like below:

```text
# DUO
#https://pan.baidu.com/s/1gSPeoSAZXGzRkfxh2O3cwQ?pwd=sxhh code: sxhh 
#https://github.com/chongweiliu/DUO
dataset
├── DUO
│   ├── images
│   │   ├── train
│   │   ├── val
│   │   ├── test
│   ├── labels
│   │   ├── train
│   │   ├── val
│   │   ├── test
```

### Training

```bash
python train.py
```

### Test

```bash
python detect.py
```